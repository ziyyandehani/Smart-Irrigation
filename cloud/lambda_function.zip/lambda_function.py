import json
import psycopg2
import os

def lambda_handler(event, context):
    body = json.loads(event['body'])

    # Data sensor TMR dan API
    rawsuhu1 = body.get('rawsuhu1')
    rawsuhu2 = body.get('rawsuhu2')
    rawsuhu3 = body.get('rawsuhu3')
    finalsuhu = body.get('finalsuhu')

    rawhum1 = body.get('rawhum1')
    rawhum2 = body.get('rawhum2')
    rawhum3 = body.get('rawhum3')
    finalhum = body.get('finalhum')

    rawsoil1 = body.get('rawsoil1')
    rawsoil2 = body.get('rawsoil2')
    rawsoil3 = body.get('rawsoil3')
    finalsoil = body.get('finalsoil')

    suhuA = body.get('suhuA')
    humidA = body.get('humidA')
    anginA = body.get('anginA')
    hujanA = body.get('hujanA')

    waktu = body.get('waktu')

    try:
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            database=os.environ['DB_NAME'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            port=5432
        )
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO sensor_data (
                rawsuhu1, rawsuhu2, rawsuhu3, finalsuhu,
                rawhum1, rawhum2, rawhum3, finalhum,
                rawsoil1, rawsoil2, rawsoil3, finalsoil,
                suhuA, humidA, anginA, hujanA, waktu
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                rawsuhu1, rawsuhu2, rawsuhu3, finalsuhu,
                rawhum1, rawhum2, rawhum3, finalhum,
                rawsoil1, rawsoil2, rawsoil3, finalsoil,
                suhuA, humidA, anginA, hujanA, waktu
            )
        )
        conn.commit()
        cur.close()
        conn.close()
        return {
            'statusCode': 200,
            'body': json.dumps('Data inserted successfully')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
